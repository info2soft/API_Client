package com.i2.Module;

public class I2 extends Base {

    public I2() {
        serverHost = "192.168.82.166:58080";
    }
}
